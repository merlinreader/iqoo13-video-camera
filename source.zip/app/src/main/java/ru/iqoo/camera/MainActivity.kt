package ru.iqoo.camera

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** Self-contained native Android Camera2 recorder. No network permission or cloud services. */
class MainActivity : Activity(), TextureView.SurfaceTextureListener {
    private data class VideoMode(val width: Int, val height: Int, val fps: Int) {
        override fun toString(): String = "${if (width >= 3840) "4K" else "1080p"} / $fps"
    }
    private data class Lens(val id: String, val facing: Int, val focal: Float?) {
        override fun toString(): String = "${when(facing) {
            CameraCharacteristics.LENS_FACING_FRONT -> "Фронтальная"
            CameraCharacteristics.LENS_FACING_BACK -> "Задняя"
            else -> "Внешняя"
        }} · ID $id${focal?.let { " · ${"%.1f".format(Locale.US, it)} мм" } ?: ""}"
    }

    private lateinit var cameraManager: CameraManager
    private lateinit var preview: TextureView
    private lateinit var recordButton: Button
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var lensSpinner: Spinner
    private lateinit var qualitySpinner: Spinner
    private lateinit var codecSpinner: Spinner
    private lateinit var presetSpinner: Spinner
    private lateinit var evBar: SeekBar
    private lateinit var focusBar: SeekBar
    private lateinit var focusLabel: TextView
    private lateinit var aeLock: CheckBox
    private lateinit var awbLock: CheckBox
    private lateinit var afLock: CheckBox
    private var afLockNeedsTrigger = false
    private lateinit var stabilize: CheckBox
    private lateinit var lastVideoButton: Button

    private val lenses = mutableListOf<Lens>()
    private val modes = mutableListOf<VideoMode>()
    private val codecs = mutableListOf<String>()
    private var selectedLens = 0
    private var selectedMode = 0
    private var selectedCodec = 0
    private var selectedPreset = 0
    private var camera: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var previewSurface: Surface? = null
    private var requestBuilder: CaptureRequest.Builder? = null
    private var recorder: MediaRecorder? = null
    private var outputFd: ParcelFileDescriptor? = null
    private var pendingUri: Uri? = null
    private var lastUri: Uri? = null
    private var recording = false
    private var preparing = false
    private var suspended = false
    private var generation = 0
    private var sessionGeneration = 0
    private var startElapsed = 0L
    private var evValue = 0f
    private var focusValue = 0f
    private var manualFocus = false
    private var suppressUi = false
    private var lastFileResult = "Файл ещё не записывался"
    // Report real HAL measurements instead of inferring light levels from 50MP marketing specs.
    private var observedIso: Int? = null
    private var observedExposureNs: Long? = null
    private var observedRollingShutterNs: Long? = null
    private var observedEis: Int? = null
    private var observedOis: Int? = null
    private val tickHandler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refreshStatus()
            tickHandler.postDelayed(this, 1000L)
        }
    }
    private val permissions = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        buildUi()
        if (hasCameraPermission()) discover() else requestPermissions(permissions, 100)
    }

    override fun onResume() {
        super.onResume()
        suspended = false
        tickHandler.post(tick)
        if (hasCameraPermission() && ::preview.isInitialized && preview.isAvailable) openSelectedCamera()
    }

    override fun onPause() {
        suspended = true
        tickHandler.removeCallbacks(tick)
        if (recording || preparing) stopRecording(restorePreview = false)
        closeCamera()
        super.onPause()
    }

    private fun hasCameraPermission() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun hasAudioPermission() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, requested: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, requested, results)
        if (requestCode == 100) {
            if (hasCameraPermission()) {
                discover()
                if (preview.isAvailable) openSelectedCamera()
                if (!hasAudioPermission()) toast("Микрофон не разрешён. Видео будет без звука")
            } else status.text = "Разрешите доступ к камере в настройках Android"
        }
    }

    private fun dp(value: Int) = (resources.displayMetrics.density * value + .5f).toInt()
    private fun header(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 12f
        setPadding(dp(4), dp(3), dp(4), dp(3))
    }
    private fun action(text: String) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 13f
        minHeight = dp(44)
    }
    private fun spinner(): Spinner = Spinner(this).apply {
        setBackgroundColor(Color.rgb(34, 35, 41))
        minimumHeight = dp(43)
        setPadding(dp(8), 0, dp(6), 0)
    }
    private fun <T> fillSpinner(widget: Spinner, choices: List<T>, selected: Int) {
        val a = ArrayAdapter(this, android.R.layout.simple_spinner_item, choices.map { it.toString() })
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        widget.adapter = a
        if (choices.isNotEmpty()) widget.setSelection(selected.coerceIn(0, choices.lastIndex))
    }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        setContentView(root)
        val viewBox = FrameLayout(this)
        root.addView(viewBox, LinearLayout.LayoutParams(-1, 0, 1f))
        preview = TextureView(this).apply { surfaceTextureListener = this }
        viewBox.addView(preview, FrameLayout.LayoutParams(-1, -1))
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0x66000000)
        }
        viewBox.addView(overlay, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        info = header("iQOO Видео · готовность камеры") .apply { textSize = 15f }
        overlay.addView(info)
        status = header("Ожидание разрешений") .apply { textSize = 13f }
        overlay.addView(status)
        recordButton = action("●  ЗАПИСЬ").apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xffa81d30.toInt())
            isEnabled = false
            setOnClickListener { if (recording) stopRecording() else if (!preparing) startRecording() }
        }
        viewBox.addView(recordButton, FrameLayout.LayoutParams(dp(210), dp(62), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(20) })

        val panelScroll = ScrollView(this).apply { setBackgroundColor(0xff15161a.toInt()) }
        root.addView(panelScroll, LinearLayout.LayoutParams(-1, dp(300)))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(2), dp(8), dp(10))
        }
        panelScroll.addView(panel)
        val first = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        panel.addView(first)
        lensSpinner = spinner()
        qualitySpinner = spinner()
        val lensBox = columnFor(first, "Объектив", lensSpinner)
        val qualityBox = columnFor(first, "Разрешение / fps", qualitySpinner)
        lensBox.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        qualityBox.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        val second = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        panel.addView(second)
        codecSpinner = spinner()
        presetSpinner = spinner()
        columnFor(second, "Кодек", codecSpinner).layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        columnFor(second, "Обработка", presetSpinner).layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        fillSpinner(presetSpinner, listOf("Авто", "iPhone Look · эксп.", "Профессиональный"), 0)

        val checks = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        panel.addView(checks)
        stabilize = CheckBox(this).apply { text = "Стаб."; setTextColor(Color.WHITE); isChecked = true }
        aeLock = CheckBox(this).apply { text = "AE"; setTextColor(Color.WHITE) }
        awbLock = CheckBox(this).apply { text = "WB"; setTextColor(Color.WHITE) }
        afLock = CheckBox(this).apply { text = "AF"; setTextColor(Color.WHITE) }
        checks.addView(stabilize); checks.addView(aeLock); checks.addView(awbLock); checks.addView(afLock)
        panel.addView(header("Экспозиция EV: 0.0" ).also { exposureLabel = it })
        evBar = SeekBar(this).apply { max = 100; progress = 50 }
        panel.addView(evBar)
        focusLabel = header("Фокус: автоматический")
        panel.addView(focusLabel)
        focusBar = SeekBar(this).apply { max = 100; progress = 0; isEnabled = false }
        panel.addView(focusBar)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        panel.addView(bottom)
        val diagnostic = action("Диагностика / JSON")
        bottom.addView(diagnostic, LinearLayout.LayoutParams(0, dp(50), 1f))
        lastVideoButton = action("Последнее видео").apply { isEnabled = false }
        bottom.addView(lastVideoButton, LinearLayout.LayoutParams(0, dp(50), 1f))
        diagnostic.setOnClickListener { if (!recording) showDiagnostics() }
        lastVideoButton.setOnClickListener { openLastVideo() }
        lensSpinner.onItemSelectedListener = simpleItemListener { index ->
            if (!suppressUi && index != selectedLens && !recording && !preparing) {
                selectedLens = index; selectedMode = 0; discoverModes(); openSelectedCamera()
            }
        }
        qualitySpinner.onItemSelectedListener = simpleItemListener { index ->
            if (!suppressUi && index != selectedMode && !recording && !preparing) {
                selectedMode = index; openSelectedCamera()
            }
        }
        codecSpinner.onItemSelectedListener = simpleItemListener { index ->
            if (!suppressUi && index != selectedCodec && !recording && !preparing) {
                selectedCodec = index; discoverModes(); openSelectedCamera()
            }
        }
        presetSpinner.onItemSelectedListener = simpleItemListener { index ->
            if (!suppressUi && index != selectedPreset && !recording && !preparing) {
                selectedPreset = index
                manualFocus = false
                updateFocusUi()
                applyRepeating()
            }
        }
        stabilize.setOnCheckedChangeListener { _, _ -> if (!suppressUi) applyRepeating() }
        aeLock.setOnCheckedChangeListener { _, _ -> if (!suppressUi) applyRepeating() }
        awbLock.setOnCheckedChangeListener { _, _ -> if (!suppressUi) applyRepeating() }
        afLock.setOnCheckedChangeListener { _, checked ->
            if (!suppressUi) { afLockNeedsTrigger = checked; applyRepeating() }
        }
        evBar.setOnSeekBarChangeListener(simpleSeekListener { p ->
            evValue = (p - 50) / 25f
            exposureLabel.text = "Экспозиция EV: ${"%+.1f".format(Locale.US, evValue)}"
            applyRepeating()
        })
        focusBar.setOnSeekBarChangeListener(simpleSeekListener { p ->
            focusValue = p / 100f
            manualFocus = selectedPreset == 2 && p > 0
            updateFocusUi()
            applyRepeating()
        })
    }
    private lateinit var exposureLabel: TextView
    private fun columnFor(parent: LinearLayout, label: String, widget: View): LinearLayout {
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(3), 0, dp(3), 0) }
        column.addView(header(label))
        column.addView(widget, LinearLayout.LayoutParams(-1, dp(43)))
        parent.addView(column)
        return column
    }
    private fun simpleItemListener(fn: (Int) -> Unit) = object : android.widget.AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, position: Int, id: Long) { fn(position) }
        override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
    }
    private fun simpleSeekListener(fn: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) fn(progress) }
        override fun onStartTrackingTouch(bar: SeekBar?) {}
        override fun onStopTrackingTouch(bar: SeekBar?) {}
    }

    private fun discover() {
        lenses.clear()
        try {
            cameraManager.cameraIdList.forEach { id ->
                val c = cameraManager.getCameraCharacteristics(id)
                val facing = c.get(CameraCharacteristics.LENS_FACING) ?: -1
                if (c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)?.getOutputSizes(MediaRecorder::class.java) == null) return@forEach
                lenses.add(Lens(id, facing, c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()))
            }
            lenses.sortWith(compareBy({ if (it.facing == CameraCharacteristics.LENS_FACING_BACK) 0 else 1 }, { it.id }))
            if (lenses.isEmpty()) { status.text = "Android не предоставляет видеокамеры"; return }
            selectedLens = selectedLens.coerceIn(0, lenses.lastIndex)
            suppressUi = true
            fillSpinner(lensSpinner, lenses, selectedLens)
            suppressUi = false
            discoverCodecs()
            discoverModes()
        } catch (e: Exception) { showError("Поиск камер", e) }
    }
    private fun encoderSupports(mime: String, width: Int, height: Int, fps: Int): Boolean {
        return try {
            val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            list.codecInfos.any { info ->
                info.isEncoder && info.supportedTypes.any { it.equals(mime, true) } &&
                    try { info.getCapabilitiesForType(mime).videoCapabilities.areSizeAndRateSupported(width, height, fps.toDouble()) }
                    catch (_: Exception) { false }
            }
        } catch (_: Exception) { false }
    }
    private fun discoverCodecs() {
        codecs.clear()
        codecs.add("H.264")
        if (encoderSupports(MediaFormat.MIMETYPE_VIDEO_HEVC, 1920, 1080, 30)) codecs.add("HEVC")
        selectedCodec = selectedCodec.coerceIn(0, codecs.lastIndex)
        suppressUi = true; fillSpinner(codecSpinner, codecs, selectedCodec); suppressUi = false
    }
    private fun activeMime() = if (codecs.getOrNull(selectedCodec) == "HEVC") MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
    private fun discoverModes() {
        if (lenses.isEmpty()) return
        try {
            val c = cameraManager.getCameraCharacteristics(lenses[selectedLens].id)
            val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(MediaRecorder::class.java)?.toList().orEmpty()
            val ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList().orEmpty()
            modes.clear()
            val mime = activeMime()
            for ((w, h) in listOf(3840 to 2160, 1920 to 1080)) {
                if (sizes.none { (it.width == w && it.height == h) || (it.width == h && it.height == w) }) continue
                val frameDurationNs = try { map?.getOutputMinFrameDuration(MediaRecorder::class.java, Size(w, h)) ?: 0L } catch (_: Exception) { 0L }
                for (fps in listOf(30, 60)) {
                    val hasFpsRange = ranges.any { it.upper >= fps && it.lower <= fps }
                    // An unknown/zero duration is NOT evidence that 60fps is supported.
                    val streamOk = fps == 30 || (frameDurationNs > 0 && frameDurationNs <= 1_000_000_000L / fps)
                    if (hasFpsRange && streamOk && encoderSupports(mime, w, h, fps)) modes.add(VideoMode(w, h, fps))
                }
            }
            if (modes.isEmpty()) {
                // Fallback for OEM Camera2 metadata missing fixed stream min durations.
                val size = sizes.firstOrNull { it.width <= 1920 && it.height <= 1080 }
                if (size != null && encoderSupports(mime, size.width, size.height, 30)) modes.add(VideoMode(size.width, size.height, 30))
            }
            selectedMode = selectedMode.coerceIn(0, max(0, modes.lastIndex))
            suppressUi = true; fillSpinner(qualitySpinner, modes, selectedMode); suppressUi = false
            recordButton.isEnabled = modes.isNotEmpty() && camera != null && !preparing && !recording
            val focusMax = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
            focusBar.isEnabled = selectedPreset == 2 && focusMax > 0f
            afLock.isEnabled = (c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: intArrayOf()).contains(CaptureRequest.CONTROL_AF_MODE_AUTO)
            aeLock.isEnabled = c.get(CameraCharacteristics.CONTROL_AE_LOCK_AVAILABLE) == true
            awbLock.isEnabled = c.get(CameraCharacteristics.CONTROL_AWB_LOCK_AVAILABLE) == true
            val eisModes = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf()
            val oisModes = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION) ?: intArrayOf()
            stabilize.isEnabled = eisModes.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON) || oisModes.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
        } catch (e: Exception) { showError("Режимы видео", e) }
    }
    private fun updateFocusUi() {
        focusBar.isEnabled = selectedPreset == 2 && activeCharacteristics()?.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)?.let { it > 0f } == true
        focusLabel.text = if (manualFocus && selectedPreset == 2) "Фокус вручную: ${(focusValue * 100).roundToInt()}% (ближе)" else "Фокус: непрерывный авто"
    }
    private fun activeCharacteristics() = try { lenses.getOrNull(selectedLens)?.let { cameraManager.getCameraCharacteristics(it.id) } } catch (_: Exception) { null }

    private fun openSelectedCamera() {
        if (!hasCameraPermission() || suspended || !preview.isAvailable || preparing || recording || lenses.isEmpty() || modes.isEmpty()) return
        closeCamera()
        observedIso = null
        observedExposureNs = null
        observedRollingShutterNs = null
        observedEis = null
        observedOis = null
        val current = ++generation
        val lens = lenses[selectedLens]
        status.text = "Открываю ${lens}"
        try {
            cameraManager.openCamera(lens.id, object : CameraDevice.StateCallback() {
                override fun onOpened(device: CameraDevice) {
                    if (suspended || current != generation) { device.close(); return }
                    camera = device
                    openSession(false)
                }
                override fun onDisconnected(device: CameraDevice) {
                    device.close()
                    if (current == generation) { camera = null; recordButton.isEnabled = false; status.text = "Камера отключилась" }
                }
                override fun onError(device: CameraDevice, error: Int) {
                    device.close()
                    if (current == generation) { camera = null; recordButton.isEnabled = false; status.text = "Ошибка камеры: $error" }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { showError("Открытие камеры", e) }
    }
    private fun closeCamera() {
        generation++
        sessionGeneration++
        closeSession()
        try { camera?.close() } catch (_: Exception) {}
        camera = null
        recordButton.isEnabled = false
    }
    private fun closeSession() {
        sessionGeneration++
        try { captureSession?.close() } catch (_: Exception) {}
        captureSession = null
        requestBuilder = null
        try { previewSurface?.release() } catch (_: Exception) {}
        previewSurface = null
    }
    private fun openSession(withRecorder: Boolean) {
        val device = camera ?: return
        val texture = preview.surfaceTexture ?: return
        val mode = modes.getOrNull(selectedMode) ?: return
        closeSession()
        val currentSession = ++sessionGeneration
        // A 1080p preview avoids expensive double-4K output combinations.
        val previewSize = choosePreviewSize(mode)
        texture.setDefaultBufferSize(previewSize.width, previewSize.height)
        configureTransform(preview.width, preview.height, previewSize)
        val surface = Surface(texture)
        previewSurface = surface
        val outputs = mutableListOf(surface)
        val recordSurface = if (withRecorder) recorder?.surface else null
        if (withRecorder && recordSurface == null) { failRecording("Видеокодировщик не подготовлен"); return }
        if (recordSurface != null) outputs.add(recordSurface)
        try {
            device.createCaptureSession(outputs, object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (suspended || currentSession != sessionGeneration || camera !== device) { s.close(); return }
                    captureSession = s
                    try {
                        val b = device.createCaptureRequest(if (withRecorder) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW)
                        b.addTarget(surface)
                        recordSurface?.let { b.addTarget(it) }
                        requestBuilder = b
                        applyRepeating()
                        if (withRecorder) {
                            recorder?.start()
                            preparing = false
                            recording = true
                            startElapsed = SystemClock.elapsedRealtime()
                            recordButton.isEnabled = true
                            recordButton.text = "■  СТОП"
                            status.text = "● Идёт запись, сохраняйте после остановки"
                            setControlsEnabled(false)
                        } else {
                            recordButton.isEnabled = modes.isNotEmpty()
                            refreshStatus()
                        }
                    } catch (e: Exception) {
                        if (withRecorder) failRecording("Не удалось начать запись: ${e.message}")
                        else showError("Предпросмотр", e)
                    }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    s.close()
                    if (currentSession == sessionGeneration) {
                        if (withRecorder) failRecording("Камера отклонила выбранный режим")
                        else status.text = "Режим предварительного просмотра недоступен"
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            if (withRecorder) failRecording("Ошибка настройки записи: ${e.message}")
            else showError("Сессия камеры", e)
        }
    }
    private fun choosePreviewSize(recordMode: VideoMode): Size {
        val sizes = activeCharacteristics()?.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?.getOutputSizes(SurfaceTexture::class.java)?.toList().orEmpty()
        return sizes.filter { it.width <= 1920 && it.height <= 1080 && it.width * 9 == it.height * 16 }
            .maxByOrNull { it.width * it.height }
            ?: sizes.filter { it.width <= 1920 && it.height <= 1080 }.maxByOrNull { it.width * it.height }
            ?: Size(recordMode.width, recordMode.height)
    }
    private fun configureTransform(viewWidth: Int, viewHeight: Int, size: Size) {
        if (viewWidth <= 0 || viewHeight <= 0) return
        // Camera2 streams are sensor-landscape; rotate/crop the TextureView in portrait.
        val rotation = windowManager.defaultDisplay.rotation
        val sensor = activeCharacteristics()?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val screenDegrees = when(rotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
        val facing = lenses.getOrNull(selectedLens)?.facing
        val relative = if (facing == CameraCharacteristics.LENS_FACING_FRONT)
            (sensor + screenDegrees) % 360 else (sensor - screenDegrees + 360) % 360
        val swapped = relative == 90 || relative == 270
        val effectiveWidth = if (swapped) size.height.toFloat() else size.width.toFloat()
        val effectiveHeight = if (swapped) size.width.toFloat() else size.height.toFloat()
        val scale = max(viewWidth / effectiveWidth, viewHeight / effectiveHeight)
        val m = Matrix()
        m.setScale(size.width * scale / viewWidth, size.height * scale / viewHeight,
            viewWidth / 2f, viewHeight / 2f)
        m.postRotate(relative.toFloat(), viewWidth / 2f, viewHeight / 2f)
        preview.setTransform(m)
    }

    private fun applyRepeating() {
        if (!hasCameraPermission()) return
        val builder = requestBuilder ?: return
        val session = captureSession ?: return
        val c = activeCharacteristics() ?: return
        val mode = modes.getOrNull(selectedMode) ?: return
        try {
            val ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList().orEmpty()
            val chosen = ranges.filter { it.upper >= mode.fps && it.lower <= mode.fps }
                .minWithOrNull(compareBy<Range<Int>> { it.upper - it.lower }.thenBy { abs(it.upper - mode.fps) })
            if (chosen != null) builder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, chosen)
            builder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
            val focusMax = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
            val manual = selectedPreset == 2 && manualFocus && focusMax > 0f
            val afModes = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: intArrayOf()
            if (manual && afModes.contains(CaptureRequest.CONTROL_AF_MODE_OFF)) {
                builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, (focusValue * focusMax).coerceIn(0f, focusMax))
            } else {
                builder.set(CaptureRequest.CONTROL_AF_MODE, when {
                    afLock.isChecked && afModes.contains(CaptureRequest.CONTROL_AF_MODE_AUTO) -> CaptureRequest.CONTROL_AF_MODE_AUTO
                    afModes.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO) -> CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                    afModes.contains(CaptureRequest.CONTROL_AF_MODE_AUTO) -> CaptureRequest.CONTROL_AF_MODE_AUTO
                    else -> CaptureRequest.CONTROL_AF_MODE_OFF
                })
            }
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            if (c.get(CameraCharacteristics.CONTROL_AE_LOCK_AVAILABLE) == true) builder.set(CaptureRequest.CONTROL_AE_LOCK, aeLock.isChecked)
            if (c.get(CameraCharacteristics.CONTROL_AWB_LOCK_AVAILABLE) == true) builder.set(CaptureRequest.CONTROL_AWB_LOCK, awbLock.isChecked)
            val step = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
            val range = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
            // Slight highlight protection, not a fabricated HDR mode. In dark scenes,
            // an extra underexposure would increase noise after lifting shadows.
            val measuredIso = observedIso ?: 0
            val highlightBias = if (selectedPreset == 1 && measuredIso in 1..640) -0.25f else 0f
            val targetEv = evValue + highlightBias
            if (step > 0f && range != null) {
                builder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION,
                    (targetEv / step).roundToInt().coerceIn(range.lower, range.upper))
            }
            val eis = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf()
            val ois = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION) ?: intArrayOf()
            val eisOn = stabilize.isChecked && eis.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
            if (eisOn) builder.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
            else if (eis.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)) builder.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)
            // HALs often disallow concurrent EIS + OIS. Prefer EIS during walking.
            if (ois.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)) {
                builder.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, if (stabilize.isChecked && !eisOn)
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON else CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF)
            }
            if (selectedPreset == 1) {
                val edges = c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES) ?: intArrayOf()
                // Avoid harsh edge halos. Do not turn off hardware processing entirely on a HAL
                // that does not advertise an OFF option.
                if (edges.contains(CaptureRequest.EDGE_MODE_OFF)) builder.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF)
                if (mode.fps <= 30) {
                    // HIGH_QUALITY stages can be too expensive for 4K/60 on some chipsets.
                    val tones = c.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES) ?: intArrayOf()
                    if (tones.contains(CaptureRequest.TONEMAP_MODE_HIGH_QUALITY)) builder.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_HIGH_QUALITY)
                    val noise = c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES) ?: intArrayOf()
                    if (noise.contains(CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)) builder.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                }
            }
            if (afLockNeedsTrigger && !manual && afModes.contains(CaptureRequest.CONTROL_AF_MODE_AUTO)) {
                afLockNeedsTrigger = false
                builder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
                session.capture(builder.build(), null, Handler(Looper.getMainLooper()))
            }
            builder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE)
            session.setRepeatingRequest(builder.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                    observedIso = result.get(CaptureResult.SENSOR_SENSITIVITY)
                    observedExposureNs = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
                    observedRollingShutterNs = result.get(CaptureResult.SENSOR_ROLLING_SHUTTER_SKEW)
                    observedEis = result.get(CaptureResult.CONTROL_VIDEO_STABILIZATION_MODE)
                    observedOis = result.get(CaptureResult.LENS_OPTICAL_STABILIZATION_MODE)
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { status.text = "Предупреждение: параметры камеры отклонены: ${e.message}" }
    }
    private fun setControlsEnabled(enabled: Boolean) {
        for (view in listOf(lensSpinner, qualitySpinner, codecSpinner, presetSpinner, stabilize, aeLock, awbLock, afLock)) view.isEnabled = enabled
        if (enabled) discoverModes() else focusBar.isEnabled = false
    }
    private fun startRecording() {
        if (recording || preparing || camera == null || modes.isEmpty()) return
        if (!hasCameraPermission()) { requestPermissions(permissions, 100); return }
        preparing = true
        recordButton.isEnabled = false
        status.text = "Подготовка записи…"
        val mode = modes[selectedMode]
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "iQOO_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4")
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/iQOO Camera")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            pendingUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Не удалось создать запись в галерее")
            outputFd = contentResolver.openFileDescriptor(pendingUri!!, "w")
                ?: throw IllegalStateException("Не удалось открыть файл")
            val mr = MediaRecorder()
            recorder = mr
            mr.setOnErrorListener { _, what, extra -> runOnUiThread { failRecording("Ошибка кодировщика: $what / $extra") } }
            if (hasAudioPermission()) mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setVideoEncoder(if (activeMime() == MediaFormat.MIMETYPE_VIDEO_HEVC) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            mr.setVideoSize(mode.width, mode.height)
            mr.setVideoFrameRate(mode.fps)
            mr.setVideoEncodingBitRate(if (mode.width >= 3840) (if (mode.fps >= 60) 85_000_000 else 55_000_000) else (if (mode.fps >= 60) 28_000_000 else 18_000_000))
            if (hasAudioPermission()) {
                mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                mr.setAudioEncodingBitRate(192_000)
                mr.setAudioSamplingRate(48_000)
            }
            val c = activeCharacteristics()
            val sensorOrientation = c?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val rotationDegrees = when (windowManager.defaultDisplay.rotation) {
                Surface.ROTATION_90 -> 90
                Surface.ROTATION_180 -> 180
                Surface.ROTATION_270 -> 270
                else -> 0
            }
            val orientation = if (lenses[selectedLens].facing == CameraCharacteristics.LENS_FACING_FRONT)
                (sensorOrientation + rotationDegrees) % 360
            else (sensorOrientation - rotationDegrees + 360) % 360
            mr.setOrientationHint(orientation)
            mr.setOutputFile(outputFd!!.fileDescriptor)
            mr.prepare()
            openSession(true)
        } catch (e: Exception) { failRecording("Подготовка записи: ${e.message}") }
    }
    private fun stopRecording(restorePreview: Boolean = true) {
        if (!recording && !preparing) return
        val wasRecording = recording
        recording = false
        preparing = false
        recordButton.isEnabled = false
        closeSession()
        var valid = false
        try {
            if (wasRecording) { recorder?.stop(); valid = true }
        } catch (_: RuntimeException) {
            status.text = "Слишком короткая или прерванная запись. Файл удалён"
        } finally {
            releaseRecorder(valid)
        }
        setControlsEnabled(true)
        recordButton.text = "●  ЗАПИСЬ"
        if (restorePreview && !suspended) openSession(false)
    }
    private fun releaseRecorder(success: Boolean) {
        try { recorder?.reset() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { outputFd?.close() } catch (_: Exception) {}
        outputFd = null
        val uri = pendingUri
        pendingUri = null
        if (uri != null) {
            if (success) {
                try {
                    contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                    lastUri = uri
                    lastVideoButton.isEnabled = true
                    lastFileResult = "Сохранено: $uri (проверка характеристик…)"
                    verifyVideo(uri)
                } catch (e: Exception) {
                    status.text = "Не удалось показать файл в галерее: ${e.message}"
                }
            } else {
                try { contentResolver.delete(uri, null, null) } catch (_: Exception) {}
            }
        }
    }
    private fun failRecording(message: String) {
        if (recording || preparing) stopRecording(restorePreview = false)
        status.text = message
        toast(message)
        if (!suspended && camera != null) openSession(false)
    }
    private fun verifyVideo(uri: Uri) {
        Thread {
            val result = try {
                val mm = MediaMetadataRetriever()
                mm.setDataSource(this, uri)
                val w = mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "?"
                val h = mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"
                val duration = (mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000f
                mm.release()
                val extractor = MediaExtractor()
                extractor.setDataSource(this, uri, null)
                var framesPerSecond = "не определена"
                for (i in 0 until extractor.trackCount) {
                    val format = extractor.getTrackFormat(i)
                    if (!(format.getString(MediaFormat.KEY_MIME) ?: "").startsWith("video/")) continue
                    extractor.selectTrack(i)
                    val frameTimes = mutableListOf<Long>()
                    while (frameTimes.size < 121 && extractor.sampleTime >= 0) {
                        frameTimes.add(extractor.sampleTime)
                        if (!extractor.advance()) break
                    }
                    if (frameTimes.size >= 12 && frameTimes.last() > frameTimes.first()) {
                        framesPerSecond = "%.1f".format(Locale.US, (frameTimes.size - 1) * 1_000_000.0 / (frameTimes.last() - frameTimes.first()))
                    }
                    break
                }
                extractor.release()
                "MP4 $w×$h · ${framesPerSecond} fps (оценка) · ${"%.1f".format(Locale.US, duration)} с"
            } catch (e: Exception) { "Файл сохранён, проверка MP4 не удалась: ${e.message}" }
            runOnUiThread {
                lastFileResult = result
                if (!recording && !preparing) status.text = result
            }
        }.start()
    }
    private fun openLastVideo() {
        val uri = lastUri ?: return
        try { startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "video/mp4"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
        catch (_: Exception) { toast("Не найден видеоплеер для MP4") }
    }
    private fun refreshStatus() {
        if (!::info.isInitialized) return
        val mode = modes.getOrNull(selectedMode)
        val freeGb = try { StatFs(filesDir.path).availableBytes / 1_073_741_824.0 } catch (_: Exception) { -1.0 }
        val iso = observedIso
        val exposure = observedExposureNs
        val exposureLabel = if (exposure != null && exposure > 0L) " · 1/${(1_000_000_000.0 / exposure).roundToInt()} с" else ""
        val exposureInfo = if (iso != null) " · ISO $iso$exposureLabel" else ""
        val dimLens = lenses.getOrNull(selectedLens)?.focal?.let { it >= 5f } == true
        val lowLightHint = if (mode != null && mode.fps >= 60 && (iso ?: 0) >= 800) " · При слабом свете лучше 30 fps" else ""
        info.text = "${mode?.toString() ?: "Нет режимов"} · ${codecs.getOrNull(selectedCodec) ?: ""} · ${"%.1f".format(Locale.US, freeGb)} ГБ$exposureInfo$lowLightHint"
        if (recording) {
            val sec = (SystemClock.elapsedRealtime() - startElapsed) / 1000
            status.text = "● REC  %02d:%02d   |   ${mode}   |   ${codecs.getOrNull(selectedCodec)}".format(sec / 60, sec % 60)
        } else if (camera != null && !preparing && !status.text.contains("MP4")) {
            status.text = "Готово к записи · ${if (selectedPreset == 1) "iPhone Look: экспериментальная аппаратная тональность" else "Нативная обработка камеры"}"
        }
    }
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    private fun showError(where: String, e: Exception) {
        status.text = "$where: ${e.javaClass.simpleName}: ${e.message ?: "неизвестная ошибка"}"
    }
    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        if (hasCameraPermission() && lenses.isNotEmpty()) openSelectedCamera()
    }
    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
        if (modes.isNotEmpty()) configureTransform(width, height, choosePreviewSize(modes[selectedMode]))
    }
    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        if (recording || preparing) stopRecording(restorePreview = false)
        closeCamera()
        return true
    }
    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}

    private fun showDiagnostics() {
        val report = diagnostics()
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Camera2 · диагностика")
            .setMessage(report.toString(2).take(7500))
            .setPositiveButton("Сохранить JSON") { _, _ ->
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "iqoo_camera2_${System.currentTimeMillis()}.json")
                }
                startActivityForResult(intent, 2701)
            }
            .setNegativeButton("Закрыть", null).create()
        dialog.show()
    }
    @Deprecated("Using the platform document picker without an extra dependency")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2701 && resultCode == RESULT_OK) data?.data?.let { uri ->
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(diagnostics().toString(2).toByteArray(Charsets.UTF_8)) }
                toast("Диагностика экспортирована")
            } catch (e: Exception) { toast("Не удалось сохранить отчёт: ${e.message}") }
        }
    }
    private fun diagnostics(): JSONObject {
        val root = JSONObject()
        root.put("app", "iQOO Видео 0.1.0; no network; Camera2+MediaRecorder; SDR")
        root.put("manufacturer", Build.MANUFACTURER)
        root.put("model", Build.MODEL)
        root.put("device", Build.DEVICE)
        root.put("android_api", Build.VERSION.SDK_INT)
        root.put("actual_previous_file", lastFileResult)
        root.put("observed_frame_iso", observedIso ?: JSONObject.NULL)
        root.put("observed_frame_exposure_ns", observedExposureNs ?: JSONObject.NULL)
        root.put("observed_frame_rolling_shutter_skew_ns", observedRollingShutterNs ?: JSONObject.NULL)
        root.put("observed_eis_mode", observedEis ?: JSONObject.NULL)
        root.put("observed_ois_mode", observedOis ?: JSONObject.NULL)
        root.put("cameras", JSONArray())
        cameraManager.cameraIdList.forEach { id ->
            val c = cameraManager.getCameraCharacteristics(id)
            val entry = JSONObject().apply {
                put("id", id)
                put("lens_facing", c.get(CameraCharacteristics.LENS_FACING))
                put("hardware_level", c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL))
                put("sensor_orientation", c.get(CameraCharacteristics.SENSOR_ORIENTATION))
                put("sensor_physical_size_mm", c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)?.let { "${it.width}x${it.height}" })
                put("sensor_pixel_array", c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)?.let { "${it.width}x${it.height}" })
                put("sensor_active_array", c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)?.toString())
                put("lens_apertures_f", asArray(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)))
                put("sensor_white_level", c.get(CameraCharacteristics.SENSOR_INFO_WHITE_LEVEL))
                put("notes_sensor", "Camera2 physical size/array describe the HAL stream, not guaranteed the precise model or binned video readout")
                put("focal_lengths_mm", asArray(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)))
                put("physical_camera_ids", JSONArray(c.physicalCameraIds.toList()))
                put("AE_target_fps_ranges", JSONArray(c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.map { "${it.lower}-${it.upper}" } ?: listOf<String>()))
                put("AE_compensation_range", c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)?.toString())
                put("AE_compensation_step", c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toString())
                put("AE_lock", c.get(CameraCharacteristics.CONTROL_AE_LOCK_AVAILABLE))
                put("AWB_lock", c.get(CameraCharacteristics.CONTROL_AWB_LOCK_AVAILABLE))
                put("minimum_focus_distance", c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE))
                put("ISO_range", c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.toString())
                put("shutter_ns", c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.toString())
                put("EIS_modes", asArray(c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)))
                put("OIS_modes", asArray(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)))
                put("edge_modes", asArray(c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)))
                put("tonemap_modes", asArray(c.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)))
                put("noise_reduction_modes", asArray(c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)))
                val map: StreamConfigurationMap? = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                put("MediaRecorder_output_sizes", JSONArray(map?.getOutputSizes(MediaRecorder::class.java)?.map { "${it.width}x${it.height}:${map.getOutputMinFrameDuration(MediaRecorder::class.java, it)}ns" } ?: emptyList<String>()))
                if (Build.VERSION.SDK_INT >= 33) {
                    val hdr = c.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)
                    put("HDR_profiles_reported_not_enabled", JSONArray(hdr?.supportedProfiles?.map { it.toString() } ?: emptyList()))
                }
            }
            root.getJSONArray("cameras").put(entry)
        }
        root.put("encoders", JSONArray().also { a ->
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { it.isEncoder }.forEach { ci ->
                val types = ci.supportedTypes.filter { it.startsWith("video/") }
                if (types.isNotEmpty()) a.put(JSONObject().put("name", ci.name).put("types", JSONArray(types)))
            }
        })
        root.put("notes", "Для реального сенсора нужен анализ Camera2 и MP4. Спецификации IMX921 1/1.56, IMX816 1/2.93, ultrawide 1/2.76 взяты с официального iqoo.com, но Camera2 может скрывать объективы. Rolling shutter, пределы ISO, шум, битность и потери света нельзя исправить LUT. EIS на 4K/60 не гарантирована. HDR/10-bit только диагностируются. FPS оценивается по временным меткам MP4.")
        return root
    }
    private fun asArray(values: IntArray?): JSONArray = JSONArray(values?.map { it } ?: emptyList<Int>())
    private fun asArray(values: FloatArray?): JSONArray = JSONArray(values?.map { it.toDouble() } ?: emptyList<Double>())
}
