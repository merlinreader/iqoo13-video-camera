package ru.iqoo.camera

import kotlin.math.max

/**
 * Source pixels are already sensor-oriented by TextureView, but the system stretches
 * them to the view bounds. This returns the corrective scales for CENTER_CROP.
 * Only the display rotation, not SENSOR_ORIENTATION, is applied by the caller.
 * Pure Kotlin so the geometry can be tested without an Android device.
 */
internal object PreviewGeometry {
    data class Scale(val x: Float, val y: Float)

    fun centerCropScale(
        viewWidth: Int, viewHeight: Int,
        streamWidth: Int, streamHeight: Int,
        sensorOrientation: Int, displayDegrees: Int
    ): Scale {
        require(viewWidth > 0 && viewHeight > 0 && streamWidth > 0 && streamHeight > 0)
        require(sensorOrientation in setOf(0, 90, 180, 270))
        require(displayDegrees in setOf(0, 90, 180, 270))

        val portraitBuffer = sensorOrientation % 180 != 0
        val originalWidth = (if (portraitBuffer) streamHeight else streamWidth).toFloat()
        val originalHeight = (if (portraitBuffer) streamWidth else streamHeight).toFloat()
        val swapForDisplay = displayDegrees % 180 != 0
        val alignedWidth = if (swapForDisplay) originalHeight else originalWidth
        val alignedHeight = if (swapForDisplay) originalWidth else originalHeight
        val scale = max(viewWidth / alignedWidth, viewHeight / alignedHeight)
        return Scale(scale * originalWidth / viewWidth, scale * originalHeight / viewHeight)
    }
}
