package ru.iqoo.camera

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PreviewGeometryTest {
    @Test fun portraitSensor90CorrectsHorizontalStretchAndCropsOnlyVertical() {
        // 16:9 camera surface is sensor-rotated to 9:16; view is about 720x924.
        val s = PreviewGeometry.centerCropScale(720, 924, 1920, 1080, 90, 0)
        assertEquals(1f, s.x, 0.001f)
        assertEquals(1280f / 924f, s.y, 0.001f)
    }

    @Test fun frontSensor270UsesSameAspectCorrection() {
        val s = PreviewGeometry.centerCropScale(720, 924, 1920, 1080, 270, 0)
        assertEquals(1f, s.x, 0.001f)
        assertEquals(1280f / 924f, s.y, 0.001f)
    }

    @Test fun matchingLandscapeAspectNeedsNoScalingOrRotation() {
        val s = PreviewGeometry.centerCropScale(1920, 1080, 1920, 1080, 0, 0)
        assertEquals(1f, s.x, 0.001f)
        assertEquals(1f, s.y, 0.001f)
    }

    @Test fun displayRotation90PreservesCircleGeometry() {
        val s = PreviewGeometry.centerCropScale(1080, 1920, 1920, 1080, 90, 90)
        assertTrue(s.x > 0f && s.y > 0f)
        // After the view rotation the x/y scale is equal in source pixels.
        val pxHorizontal = s.x * 1080f / 1080f
        val pxVertical = s.y * 1920f / 1920f
        assertEquals(pxHorizontal, pxVertical, 0.001f)
    }
}
